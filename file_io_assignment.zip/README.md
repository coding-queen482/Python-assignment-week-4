# Assignment: File Read & Write Challenge 🖋️

## Student Submission
This is my Python assignment for the **File Read & Write Challenge**.  
The task was to create a program that:
1. Reads a file given by the user.
2. Writes a modified version of the file to a new file.
3. Handles errors such as missing files or permission issues.

---

## What My Program Does 🎯
- Asks the user to type the filename.
- Reads the content of the file if it exists.
- Converts all the text to **UPPERCASE**.
- Saves the result in a new file with the name: `modified_filename`.
- Displays clear error messages if something goes wrong (e.g., file not found).

---

## Sample Run 🖥️
```
Enter the filename to read: notes.txt
✅ Successfully created 'modified_notes.txt' with modified content!
```

---

## Outcomes 🎉
By doing this assignment I learned:
- How to read and write files in Python.
- How to handle errors using `try-except`.
- How to make my program more user-friendly and robust.

---

## How to Run
```bash
python file_io_error_handling.py
```
